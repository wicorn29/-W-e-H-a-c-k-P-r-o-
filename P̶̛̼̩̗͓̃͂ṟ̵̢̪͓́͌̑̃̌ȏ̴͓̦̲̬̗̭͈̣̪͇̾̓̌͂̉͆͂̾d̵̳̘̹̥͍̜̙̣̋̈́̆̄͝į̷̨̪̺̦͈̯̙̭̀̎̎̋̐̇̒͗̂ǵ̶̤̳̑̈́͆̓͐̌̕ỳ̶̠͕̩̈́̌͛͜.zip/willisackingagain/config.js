window.config = {
   "model_": "AppConfig",
   "id": 1,
   "appName": "W̶̺̭̾͌͐ę̸͓̮̟͓̫̮̈́̀͜Ḧ̵̛̰̘̤̖̙̭̈́̄͝a̶̯͖͒̿̚͝c̵̹̞̥̩̫̦̗͚͛͛̓̇͌̾́̆̚k̴̛̼̗͙̱͂̆͜͝P̶̛̼̩̗͓̃͂ṟ̵̢̪͓́͌̑̃̌ȏ̴͓̦̲̬̗̭͈̣̪͇̾̓̌͂̉͆͂̾d̵̳̘̹̥͍̜̙̣̋̈́̆̄͝į̷̨̪̺̦͈̯̙̭̀̎̎̋̐̇̒͗̂ǵ̶̨̤̳̰̲̮̑̈́͆̓͐̌̕͜ỳ̶̠͕̩̈́̌͛͜",
   "version": "2.0",
   "homepage": "https://htmlpreview.github.io/?https://github.com/wicorn29/-W-e-H-a-c-k-P-r-o-/blob/main/index.html",
   "enableNavBttns": false,
   "enableHomeBttn": false,
   "enableReloadBttn": false,
   "enableLogoutBttn": false,
   "termsOfService": "yo this is made by the one and only wilson. DONT USE AT SCHOOL WHTEVER U DO!!!!",
   "kioskEnabled": true
};